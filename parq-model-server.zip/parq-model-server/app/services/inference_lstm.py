import numpy as np
from keras.models import load_model
import joblib
import json

model = load_model("models/trained_model.h5", compile= False)
le = joblib.load("models/label_encoder.pkl")
scaler_dict = joblib.load("models/scaler_dict.pkl")
with open("models/feature_order.json") as f:
    feature_order = json.load(f)


def preprocess(parking_lot: str, counts: list[int])-> np.ndarray:
    assert len(counts) == 24
    encoded_name = le.transform([parking_lot])[0]
    features = {"주차장명": encoded_name}
    
    for i in range(24):
        features[f"{i:02d}시"] = counts[i]

    x_input_list = [features[k] for k in feature_order]
    x_scaled = [(x-scaler_dict["mean"][k])/scaler_dict["std"][k] for x, k in zip(
        x_input_list, feature_order)]
    
    return np.array([x_scaled])

def run_lstm_prediction(data) -> dict:
    predictions = model.predict(data)[0]
    result = {}
    for i, val in enumerate(predictions):
        hour_label =f"{i:02d}시"
        result[hour_label] = int(round(val))

    return result




