package com.ParQ.ParQ.repository;

import com.ParQ.ParQ.entity.BoardReply;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BoardReplyRepository extends JpaRepository<BoardReply, Long> {
} 