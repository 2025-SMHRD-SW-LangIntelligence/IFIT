package com.ParQ.ParQ;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ParqBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(ParqBackendApplication.class, args);
	}

}
